// import React from 'react';
// import { useChecklist } from 'react-checklist';
// // or const { useChecklist } = require('react-checklist');

// const data = [
//   { _id: 1, label: 'item 1' },
//   { _id: 2, label: 'item 2' },
//   { _id: 3, label: 'item 3' },
// ]

// function TechStack()  {
//   return (
//   <div>
//   <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike"/>
//     <label for="vehicle1"> {data.i}</label><br/>
//       <input type="checkbox" id="vehicle2" name="vehicle2" value="Car"/>
//         <label for="vehicle2"> I have a car</label><br/>
//           <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat"/>
//             <label for="vehicle3"> I have a boat</label><br/>
//             </div>
//   )
// };
// export default TechStack