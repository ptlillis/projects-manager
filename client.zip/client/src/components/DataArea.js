import React, { Component } from "react";
import DataTable from "./DataTable";

// import "../styles/DataArea.css";

export default class DataArea extends Component {
  render() {
    return (
      <>
        <div className="data-area">
          <DataTable

          />
        </div>
      </>
    );
  }
}
