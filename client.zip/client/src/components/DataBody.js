import React from "react";
// import "../styles/DataBody.css";

function DataBody() {


  return (
    <tbody>
   
    </tbody>
  );
}

export default DataBody;
